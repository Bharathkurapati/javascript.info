The wrapper returned by `spy(f)` should store all arguments and then use `f.apply` to forward the call.
