The answer: `undefined`.

The result of `bind` is another object. It does not have the `test` property.

