function byField(fieldName){

  // Your code goes here.

}
