function getMessage() {
  return "Hello, world!";
}
