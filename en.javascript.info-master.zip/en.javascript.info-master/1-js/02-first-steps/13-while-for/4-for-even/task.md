importance: 5

---

# Output even numbers in the loop

Use the `for` loop to output even numbers from `2` to `10`.

[demo]
