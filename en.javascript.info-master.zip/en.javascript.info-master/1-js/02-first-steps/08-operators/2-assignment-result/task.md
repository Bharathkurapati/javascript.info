importance: 3

---

# Assignment result

What are the values of `a` and `x` after the code below?

```js
let a = 2;

let x = 1 + (a *= 2);
```
