The answer is `2`, that's the first truthy value.

```js run
alert( null || 2 || undefined );
```

