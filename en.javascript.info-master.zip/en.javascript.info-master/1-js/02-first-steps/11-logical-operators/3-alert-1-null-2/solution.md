The answer: `null`, because it's the first falsy value from the list.

```js run
alert( 1 && null && 2 );
```

