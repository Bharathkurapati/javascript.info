importance: 5

---

# What is the result of AND?

What is this code going to show?

```js
alert( 1 && null && 2 );
```

