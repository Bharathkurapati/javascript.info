The HTML code:

[html src="index.html"]

For the file `alert.js` in the same folder:

[js src="alert.js"]

