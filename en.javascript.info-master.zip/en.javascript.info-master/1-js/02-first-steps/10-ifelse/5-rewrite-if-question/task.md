importance: 5

---

# Rewrite 'if' into '?'

Rewrite this `if` using the conditional operator `'?'`:

```js
let result;

if (a + b < 4) {
  result = 'Below';
} else {
  result = 'Over';
}
```
