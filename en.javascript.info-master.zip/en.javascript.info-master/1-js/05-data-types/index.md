# Data types

More data structures and more in-depth study of the types.
